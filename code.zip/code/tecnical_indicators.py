import numpy as np
import pandas as pd
import statsmodels.api as sm

def simple_Moving_Average(arr):
    window_size = 3

    i = 0
    # Initialize an empty list to store moving averages
    moving_averages = []

    # Loop through the array t o
    # consider every window of size 3
    while i < len(arr):
        # Calculate the average of current window
        window_average = round(np.sum(arr[
                                      i:i + window_size]) / window_size, 2)

        # Store the average of current
        # window in moving average list
        moving_averages.append(window_average)

        # Shift window to right by one position
        i += 1
    return np.array(moving_averages)
def weightedmovingaverage(Data):
    weighted = []
    period = 1
    for i in range(len(Data)):

            total = np.arange(1, period + 1, 1) # weight matrix
            matrix = Data[i - period + 1: i + 1, 3:4]
            matrix = np.ndarray.flatten(matrix)
            matrix = total * matrix # multiplication
            wma = (matrix.sum()) / (total.sum()) # WMA
            weighted = np.append(weighted, wma) # add to array

    return weighted

def movingAverageExponential(values, alpha, epsilon = 0):

   if not 0 < alpha < 1:
      raise ValueError("out of range, alpha='%s'" % alpha)

   if not 0 <= epsilon < alpha:
      raise ValueError("out of range, epsilon='%s'" % epsilon)

   result = [None] * len(values)

   for i in range(len(result)):
       currentWeight = 1.0

       numerator     = 0
       denominator   = 0
       for value in values[i::-1]:
           numerator     += value * currentWeight
           denominator   += currentWeight

           currentWeight *= alpha
           if currentWeight < epsilon:
              break

       result[i] = numerator / denominator

   return np.array(result)


def momentum(data, n):

    """

    :param df: pandas.DataFrame
    :param n:
    :return: pandas.DataFrame
    """
    df = pd.DataFrame(data)
    mom =[]
    for i in range(df.shape[1]):
        M = pd.Series(df.iloc[:,i].diff(n), name='Momentum_' + str(n))
        mom.append(M)

    return (np.array(mom)).T


def rsi(data, periods=14, ema=True):
    """
    Returns a pd.Series with the relative strength index.

    """
    df = pd.DataFrame(data)
    RSI =[]
    for i in range(df.shape[1]):
        close_delta = df.iloc[:, i].diff()

        # Make two series: one for lower closes and one for higher closes
        up = close_delta.clip(lower=0)
        down = -1 * close_delta.clip(upper=0)

        if ema == True:
            # Use exponential moving average
            ma_up = up.ewm(com=periods - 1, adjust=True, min_periods=periods).mean()
            ma_down = down.ewm(com=periods - 1, adjust=True, min_periods=periods).mean()
        else:
            # Use simple moving average
            ma_up = up.rolling(window=periods, adjust=False).mean()
            ma_down = down.rolling(window=periods, adjust=False).mean()

        rsi = ma_up / ma_down
        rsi = 100 - (100 / (1 + rsi))
        RSI.append(rsi)
    return (np.array(RSI)).T



def obv(data, n):

    """

    :param df: pandas.DataFrame
    :param n:
    :return: pandas.DataFrame
    """
    df = pd.DataFrame(data)
    Obv =[]
    for i in range(df.shape[1]):
        OBV = df.iloc[:, i]
        OBV_ma = pd.Series(OBV.rolling(n, min_periods=n).mean(), name='OBV_' + str(n))
        Obv.append(OBV_ma)

    return (np.array(Obv)).T


import pandas as pd
import numpy as np



def average_directional_movement_index(df, n, n_ADX):
    """Calculate the Average Directional Movement Index for given data.

    :param df: pandas.DataFrame
    :param n:
    :param n_ADX:
    :return: pandas.DataFrame
    """
    i = 0
    UpI = []
    DoI = []
    while i + 1 < len(df):
        UpMove = df['High'].iloc[i + 1] - df['High'].iloc[i]
        DoMove = df['Low'].iloc[i] - df['Low'].iloc[i + 1]
        if UpMove > DoMove and UpMove > 0:
            UpD = UpMove
        else:
            UpD = 0
        UpI.append(UpD)
        if DoMove > UpMove and DoMove > 0:
            DoD = DoMove
        else:
            DoD = 0
        DoI.append(DoD)
        i = i + 1
    i = 0
    TR_l = [0]
    while i+1 < len(df):
        TR = max(df.iloc[i + 1][ 'High'], df.iloc[i][  'Close']) - min(df.iloc[i + 1][  'Low'], df.iloc[i][  'Close'])
        TR_l.append(TR)
        i = i + 1
    TR_s = pd.Series(TR_l)
    ATR = pd.Series(TR_s.ewm(span=n, min_periods=n).mean())
    UpI = pd.Series(UpI)
    DoI = pd.Series(DoI)
    PosDI = pd.Series(UpI.ewm(span=n, min_periods=n).mean() / ATR)
    NegDI = pd.Series(DoI.ewm(span=n, min_periods=n).mean() / ATR)
    ADX = pd.Series((abs(PosDI - NegDI) / (PosDI + NegDI)).ewm(span=n_ADX, min_periods=n_ADX).mean(),
                    name='ADX_' + str(n) + '_' + str(n_ADX))

    return np.array(ADX)
def tsf(data):
    from statsmodels.tsa.stattools import acf, pacf

    data = data.astype(float)
    ts_log = np.log(data[:,2])
    # lag_acf = acf(ts_log_diff, nlags=20)
    # lag_pacf = pacf(ts_log_diff, nlags=20, method='ols')
    # model = ARIMA(ts_log, order=(2, 1, 0))
    # results_AR = model.fit(disp=-1)
    # model = ARIMA(ts_log, order=(0, 1, 2))
    # results_MA = model.fit(disp=-1)
    model = sm.tsa.arima.ARIMA(ts_log, order=(2, 1, 2), enforce_stationarity=False, enforce_invertibility=False)
    results_ARIMA = model.fit()

    predictions_ARIMA_diff = pd.Series(results_ARIMA.fittedvalues, copy=True)
    predictions_ARIMA_diff_cumsum = predictions_ARIMA_diff.cumsum()
    predictions_ARIMA_log = pd.Series(ts_log, index=pd.DataFrame(ts_log).index)
    predictions_ARIMA = predictions_ARIMA_log.add(predictions_ARIMA_diff_cumsum, fill_value=0)
    return np.array(predictions_ARIMA)
