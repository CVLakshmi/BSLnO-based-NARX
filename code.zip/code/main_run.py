import pandas as pd
import numpy as np
import tecnical_indicators, arrange_features
import Ride_NN.ride_nn, Augmentation
import narx_nn


def process(state):
    MSE, RMSE, MAE = [], [], []

    #----- read dataset as dataframe
    df = pd.read_csv(r'dataset.csv')
    delay = 20
    for i in range(5):
        state = state.upper()
        n_df = df[df['SUBDIVISION'].str.contains(state, case=False, na=False)]
        n_df = n_df.iloc[0:delay, :]
            #----- removing string from datset by taking unique
        unique =[]
        for i in range(len(n_df)):
            if n_df.iloc[i, 1] not in unique:
                unique.append(n_df.iloc[i, 1])
                n_df.iloc[i, 1] = unique.index(n_df.iloc[i,1])
            else:
                n_df.iloc[i, 1] = unique.index(n_df.iloc[i, 1])

            #----- getting target from dataset
        df1 = n_df.drop('ANNUAL',axis = 1)
        data = np.array(df1)
        lab = np.array(n_df['ANNUAL'])

                           ##### extracting technical indicators


        sma = tecnical_indicators.simple_Moving_Average(data)
        tsf = tecnical_indicators.tsf(data)
        ema = tecnical_indicators.movingAverageExponential(data, 0.75)
        mom = tecnical_indicators.momentum(data, 5)
        obv = tecnical_indicators.obv(data, 5)
        wma = tecnical_indicators.weightedmovingaverage(data)
        rsi = tecnical_indicators.rsi(data, 5)
        adx = tecnical_indicators.average_directional_movement_index(df1, 5,3)

        wma = wma.reshape(len(wma), 1)
        sma = sma.reshape(len(sma), 1)
        tsf = tsf.reshape(len(tsf), 1)
        adx = adx.reshape(len(adx), 1)
        feat = np.concatenate((sma, tsf, ema, mom, obv, wma, rsi), axis=1).astype(float)
        feat = np.nan_to_num(feat)
        lab = np.nan_to_num(lab)

                       ###### feature_fusion
        #----- arrange features based on hamming distance
        distance_basd_arngd_featrs = arrange_features.main(feat, lab)
        #---- generating gamma using Ride NN
        gamma = Ride_NN.ride_nn.callmain(feat, lab, 0.9)

        N = feat.shape[1]     ###### number of features
        M = 50                  ##### features to be selected
        x = N / M
        I = int(M - (N / x))


            #----- fusion
        fused_data = []
        for i in range(M):
            f = (gamma/x) * distance_basd_arngd_featrs[:, I]
            fused_data.append(f)
            I += 1
        fused_data = np.array(fused_data).T

                           #### Augmentation SMOTE technique
        Aug_data,Aug_lab = Augmentation.augment(fused_data, lab, 10000)

        Aug_lab = Aug_lab.reshape(Aug_lab.shape[1], 1)



        #------------ proposed methodology for rainfall prediction ---------------
        narx_nn.classify(Aug_data, Aug_lab, MSE, RMSE, MAE)

        delay += 20
    return MSE, RMSE, MAE
process('bihar') #"bihar", "orissa", 'Punjab', 'Tamil nadu'