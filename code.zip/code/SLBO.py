from numpy.random import uniform, randint, normal, random, choice, rand
from numpy import abs, sign, cos, pi, sin, sqrt, power
from copy import deepcopy
from mealpy.root import Root
import random
import numpy as np
class SLBO(Root):
    """
        My improved version of: Improved Sea Lion Optimization Algorithm
            (Sea Lion Optimization Algorithm)
    """
    ID_POS_LOC = 2
    ID_POS_FIT = 3

    def __init__(self, obj_func=None, lb=None, ub=None,problem_size=50, batch_size=10, verbose=True, MaxIter=750, pop_size=100, c1=1.2, c2=1.2):
        super().__init__(obj_func, lb, ub,problem_size, batch_size, verbose)
        self.func = 50
        self.MaxIter = MaxIter
        self.pop_size = pop_size
        self.c1 = c1
        self.c2 = c2
        self.N = 50
        self.ND = 20
        self.a2 = 1
        nd =20
        lb1 = -32 * np.ones(nd)
        ub1 = 32 * np.ones(nd)

        self.pos = np.random.uniform(low=lb1, high=ub1, size=(self.N, self.ND))
    def fitness(self):
        fit_val = []
        for i in self.pos:
            fit_val.append(self.func)
        return np.array(fit_val)

    def create_solution(self, minmax=0):
        position = uniform(self.lb, self.ub)
        fitness = self.get_fitness_position(position=position, minmax=minmax)
        local_pos = self.lb + self.ub - position
        local_fit = self.get_fitness_position(position=local_pos, minmax=minmax)
        if fitness < local_fit:
            return [local_pos, local_fit, position, fitness]
        else:
            return [position, fitness, local_pos, local_fit]

    def train(self):
        pop = [self.create_solution() for _ in range(self.pop_size)]
        g_best = self.get_global_best_solution(pop, self.ID_FIT, self.ID_MIN_PROB)

        for MaxIter in range(self.MaxIter):
            c = 2 - 2 * MaxIter / self.MaxIter
            t0 = random.random()
            v1 = sin(2 * pi * t0)           ### eqn 4
            v2 = sin(2 * pi * (1 - t0))             ### eqn 5
            SP_leader = abs(v1 * (1 + v2) / v2)      ### eqn 3

            for i in range(1,self.pop_size):
                if SP_leader < 0.5:
                    if c < 1:   # Exploitation
                        dif1 = abs(2 * random.random() * g_best[self.ID_POS] - pop[i][self.ID_POS])        #### eqn 1
                        dif2 = abs(2 * random.random() * pop[i][self.ID_POS_LOC] - pop[i][self.ID_POS])
                        pos_new = self.c1 * random.random() * (pop[i][self.ID_POS] - c * dif1) + self.c2*random.random() *(pop[i][self.ID_POS] - c*dif2)
                    else:   # Exploration
                        pos_new = g_best[self.ID_POS] + c * normal(0, 1, self.problem_size) * (g_best[self.ID_POS] - pop[i][self.ID_POS])
                        fit_new = self.get_fitness_position(pos_new)
                        pos_new_oppo = self.lb + self.ub - g_best[self.ID_POS] + random.random() * (g_best[self.ID_POS] - pos_new)
                        fit_new_oppo = self.get_fitness_position(pos_new_oppo)
                        if fit_new_oppo < fit_new:
                            pos_new = pos_new_oppo

                else:           #### eqn 6
                    fit_val = self.fitness()
                    eps = 10e-8
                    sum = np.sum(fit_val)
                    # print(sum)          ### eqn 3
                     ### eqn 4
                    S = self.a2 * np.exp((fit_val[i] - fit_val[MaxIter]) * self.N * fit_val[i] / (
                            np.abs(fit_val[i] - fit_val[MaxIter]) + sum +eps))

                    if S > 10:
                        S = 10
                    sumvector = np.zeros(self.ND)
                    for item in self.pos:
                        sumvector += item
                    meanj = sumvector / self.N
                    rand = random.uniform(0,1)
                    #----- proposed SLBO eqn updated
                    pos_new = (1 / 2- rand * (1+S))*(self.pos[i-1][i-1]* (cos(2 * pi * uniform(-1, 1)+1)*(1- rand) * (1+S)-(-(pop[i][self.ID_POS])*rand -g_best[self.ID_POS] * S *rand)*cos(2 * pi * uniform(-1, 1))))

                pos_new = self.amend_position_random_faster(pos_new)
                fit = self.get_fitness_position(pos_new)
                if fit < pop[i][self.ID_POS_FIT]:
                    pop[i] = [pos_new, fit, deepcopy(pos_new), deepcopy(fit)]
                else:
                    pop[i][self.ID_POS] = pos_new
                    pop[i][self.ID_FIT] = fit
            g_best = self.update_global_best_solution(pop, self.ID_MIN_PROB, g_best)
            self.loss_train.append(g_best[self.ID_FIT])

        self.solution = g_best
        return g_best[self.ID_POS], g_best[self.ID_FIT], self.loss_train
def obj_func(s):
    return random.random()

def opt():
    problemsize = 5
    lb = [-5] * problemsize
    ub = [5] * problemsize
    slo_ = SLBO(obj_func, lb=lb, ub=ub, pop_size=10, problem_size=problemsize, MaxIter=50, verbose=False)
    bes_pos1, bes_fit1, bes_loss1 = slo_.train()
    return bes_fit1
