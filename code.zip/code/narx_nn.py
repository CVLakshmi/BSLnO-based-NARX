from tensorflow import keras
from keras import layers
import tensorflow as tf
from sklearn.metrics import mean_squared_error,mean_absolute_error
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam as opt
import SLBO
import numpy as np


def classify(X,Y,MSE, RMSE, MAE):
    n_clas = len(np.unique(Y))
    X_train, X_test, y_train, y_test = train_test_split(X, Y, train_size=0.9999, random_state=42)
    target = y_test
    narx_model = keras.Sequential([
        layers.Dense(10, activation='tanh',input_shape=(X_train.shape[1],)),
        layers.Dense(n_clas, activation='relu')
    ])

    narx_model.compile(
        optimizer=opt(learning_rate=SLBO.opt()),
        loss='mse',
        metrics=['accuracy']
    )
    callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=3)
    narx_model.fit(X_train, y_train, epochs=100, validation_split=0.2, verbose=0, callbacks=[callback])



    pred = narx_model(X_test)


    Mse = mean_squared_error(pred, target)
    Rmse = np.sqrt(Mse)
    Mae = mean_absolute_error(pred,target)
    MSE.append(Mse)
    RMSE.append(Rmse)
    MAE.append(Mae)

