import numpy as np

# Hamming Distance
def Hamming_Distance(x,y):
    a = 0
    for i in range(len(x)):
        a += np.nan_to_num(np.abs((x[i])-(y[i])))    ####abs - modulus

    hd = len(x) * a
    return hd


def main(Data,Label):
    Hamming_Dist = []
    for i in range(Data.shape[1]):
        Hamming_Dist.append(Hamming_Distance(Data[:,i],Label))
    fs = 79 # feature size
    ind = []
    arr = np.copy(Hamming_Dist)
    for i in range(len(Hamming_Dist)):
        best = np.argmax(arr)  # maximum index of arr
        ind.append(best)  # Index of the maximum value
        arr[best] = -1  # set by min, to get next best
    feature = []
    for ii in range(fs):
        datas = Data[:,ind[ii]]  # selecting the columns having the maximum index value in the dataset
        feature.append(datas)
    feature = np.transpose(feature).tolist()  # transposing the data

    len_feat = len(feature)
    feature = feature

    feat = np.array(feature)

    return feat